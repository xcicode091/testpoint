<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dayah_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_all_dayah() {
        $this->db->select('dayah.*, kecamatan.nama_kecamatan');
        $this->db->from('dayah');
        $this->db->join('kecamatan', 'kecamatan.id = dayah.kecamatan_id');
        return $this->db->get()->result();
    }

    public function get_dayah_by_id($id) {
        $this->db->where('id', $id);
        return $this->db->get('dayah')->row();
    }

    public function create_dayah($data) {
        $this->db->insert('dayah', $data);
        return $this->db->insert_id();
    }

    public function update_dayah($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('dayah', $data);
    }

    public function delete_dayah($id) {
        $this->db->where('id', $id);
        return $this->db->delete('dayah');
    }

    public function get_dayah_geojson() {
        $query = $this->db->query("
            SELECT 
                dayah.id,
                dayah.nama_dayah,
                dayah.latitude,
                dayah.longitude,
                dayah.jumlah_santri,
                kecamatan.nama_kecamatan
            FROM dayah
            JOIN kecamatan ON kecamatan.id = dayah.kecamatan_id
            WHERE dayah.status = 'aktif'
        ");
        return $query->result();
    }

    public function get_statistik_kecamatan() {
        $query = $this->db->query("
            SELECT 
                kecamatan.nama_kecamatan,
                COUNT(dayah.id) as jumlah_dayah,
                SUM(dayah.jumlah_santri) as total_santri
            FROM kecamatan
            LEFT JOIN dayah ON kecamatan.id = dayah.kecamatan_id
            GROUP BY kecamatan.id
        ");
        return $query->result();
    }
}