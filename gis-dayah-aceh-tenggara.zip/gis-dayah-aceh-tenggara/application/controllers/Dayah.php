<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dayah extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Dayah_model');
        if (!$this->session->userdata('logged_in')) {
            redirect('auth/login');
        }
    }

    // Admin CRUD Functions
    public function index() {
        $data['dayah'] = $this->Dayah_model->get_all_dayah();
        $this->load->view('adminlte/header');
        $this->load->view('dayah/index', $data);
        $this->load->view('adminlte/footer');
    }

    public function create() {
        $this->load->helper('form');
        $this->load->library('form_validation');

        $this->form_validation->set_rules('nama_dayah', 'Nama Dayah', 'required');
        // Tambahkan rule validasi lainnya

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('adminlte/header');
            $this->load->view('dayah/create');
            $this->load->view('adminlte/footer');
        } else {
            // Handle file upload
            $config['upload_path'] = './assets/images/dayah/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = 2048;

            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('foto')) {
                $error = array('error' => $this->upload->display_errors());
                // Tampilkan error
            } else {
                $data = $this->input->post();
                $upload_data = $this->upload->data();
                $data['foto'] = $upload_data['file_name'];

                $this->Dayah_model->create_dayah($data);
                $this->session->set_flashdata('success', 'Data dayah berhasil ditambahkan');
                redirect('dayah');
            }
        }
    }

    // Fungsi edit, update, delete, view...

    // Public Landing Page
    public function landing_page() {
        $data['dayah_list'] = $this->Dayah_model->get_all_dayah();
        $data['statistik'] = $this->Dayah_model->get_statistik_kecamatan();
        $this->load->view('landing_page', $data);
    }

    // API untuk data GIS
    public function api_dayah() {
        $data = $this->Dayah_model->get_dayah_geojson();
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($data));
    }
}