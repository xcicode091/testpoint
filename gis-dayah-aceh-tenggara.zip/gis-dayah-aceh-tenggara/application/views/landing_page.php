<!DOCTYPE html>
<html lang="id">
<head>
    <!-- Meta tags, CSS, JS seperti sebelumnya -->
</head>
<body>
    <!-- Navbar, Hero Section seperti sebelumnya -->

    <!-- Peta Section dengan Data Dinamis -->
    <section id="peta" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Peta Dayah Aceh Tenggara</h2>
            <div class="map-container mb-4" id="dayahMap"></div>
            
            <div class="row">
                <?php foreach ($dayah_list as $dayah): ?>
                <div class="col-md-4 mb-4">
                    <div class="card dayah-card">
                        <?php if ($dayah->foto): ?>
                        <img src="<?= base_url('assets/images/dayah/'.$dayah->foto) ?>" class="card-img-top" alt="<?= $dayah->nama_dayah ?>">
                        <?php else: ?>
                        <img src="<?= base_url('assets/images/dayah-default.jpg') ?>" class="card-img-top" alt="Default Dayah Image">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?= $dayah->nama_dayah ?></h5>
                            <p class="card-text">
                                Kecamatan: <?= $dayah->nama_kecamatan ?><br>
                                Santri: <?= $dayah->jumlah_santri ?>, Ustadz: <?= $dayah->jumlah_ustadz ?>
                            </p>
                            <span class="badge badge-dayah text-white"><?= ucfirst($dayah->status) ?></span>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Statistik Section dengan Data Dinamis -->
    <section id="statistik" class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Statistik Dayah</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Jumlah Dayah per Kecamatan</h5>
                            <canvas id="kecamatanChart" height="300"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Total Santri per Kecamatan</h5>
                            <canvas id="santriChart" height="300"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        // Inisialisasi peta dengan data dinamis
        const map = L.map('dayahMap').setView([3.3167, 97.9167], 10);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Ambil data dayah dari API
        fetch('<?= site_url('dayah/api_dayah') ?>')
            .then(response => response.json())
            .then(data => {
                data.forEach(dayah => {
                    L.marker([dayah.latitude, dayah.longitude]).addTo(map)
                        .bindPopup(`
                            <b>${dayah.nama_dayah}</b><br>
                            Kecamatan: ${dayah.nama_kecamatan}<br>
                            Santri: ${dayah.jumlah_santri}
                        `);
                });
            });

        // Grafik statistik
        const kecamatanLabels = <?= json_encode(array_column($statistik, 'nama_kecamatan')) ?>;
        const jumlahDayahData = <?= json_encode(array_column($statistik, 'jumlah_dayah')) ?>;
        const totalSantriData = <?= json_encode(array_column($statistik, 'total_santri')) ?>;

        new Chart(document.getElementById('kecamatanChart'), {
            type: 'bar',
            data: {
                labels: kecamatanLabels,
                datasets: [{
                    label: 'Jumlah Dayah',
                    data: jumlahDayahData,
                    backgroundColor: '#2c5a78'
                }]
            }
        });

        new Chart(document.getElementById('santriChart'), {
            type: 'bar',
            data: {
                labels: kecamatanLabels,
                datasets: [{
                    label: 'Total Santri',
                    data: totalSantriData,
                    backgroundColor: '#3a9d23'
                }]
            }
        });
    </script>
</body>
</html>